<div class="something">
  <?php _e('Advertisement', 'default'); ?>		
  <div class="somethingspecial">
    <?php echo get_option('google_adsense_bottom'); ?>
  </div>
</div>