</div> <!-- #main -->

<?php wp_footer(); ?>

<?php // Sully Denons « Organical Code » - No animals were harmed during the testing of this theme. ?>

<?php echo get_option('google_analytics'); ?>

</body>
</html>
