<?php /* Fusion/digitalnature

 Template Name: 2 column template (for active 3-col option)
 */
 
 include(TEMPLATEPATH . '/page.php');
 // exactly the same as page.php (only file name is needed for the 2 col check)
?>
