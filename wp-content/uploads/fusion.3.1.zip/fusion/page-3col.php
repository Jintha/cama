<?php /* Fusion/digitalnature

 Template Name: 3 column template
 */
 
 include(TEMPLATEPATH . '/page.php');
 // exactly the same as page.php (only file name is needed for the 3 col check)
?>
