<?php /* Fusion/digitalnature

Template Name: Page without sidebar(s)
*/

 include(TEMPLATEPATH . '/page.php');
 // exactly the same as page.php (only file name is needed for the no-sidebar check)
?>
